#Metodos Basados En La Derivada

from .Metodo_Newton_Raphson import metodo_newton_raphson
from .Metodo_Biseccion import encontrar_raiz
from .Metodo_Secante import met_secante