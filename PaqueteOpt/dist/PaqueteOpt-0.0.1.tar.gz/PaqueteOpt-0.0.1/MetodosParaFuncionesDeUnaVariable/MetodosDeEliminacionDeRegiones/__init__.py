#Metodos De Eliminacion De Regiones

from .Metodo_Division_Intervalos import division_por_intervalos
from .Busqueda_Fibonacci import busqueda_fibonacci
from .Metodo_Seccion_Dorada import busqueda_seccion_dorada