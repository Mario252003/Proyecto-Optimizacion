#Parcial1

from .Ejercicio_Caja import calcular_punto
from .Ejercicio_Cerca import CalculoCerca
from .Ejercicio_Lata2 import calcular_lata
from .Ejercicio_Lata import calcular_area_superficie